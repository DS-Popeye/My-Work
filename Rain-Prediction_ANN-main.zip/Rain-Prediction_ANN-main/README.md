# Rain-Prediction_ANN
# Predict next-day rain by training classification models on the target variable RainTomorrow.
# ContentThis dataset contains about 10 years of daily weather observations from many locations across Australia.
# RainTomorrow is the target variable to predict. It means -- did it rain the next day, Yes or No? This column is Yes if the rain for that day was 1mm or more.
